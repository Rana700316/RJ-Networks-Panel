RJ NETWORKS - FULL BUILD

Is package mein:
1) web/index.html + web/config.js = mobile-friendly online panel
2) sql/rj_networks_schema.sql = cloud database
3) sql/whatsapp_reminder_schema.sql = WhatsApp reminder log
4) supabase/functions/whatsapp-expiry/index.ts = automatic WhatsApp reminder function
5) sql/schedule.sql = daily schedule example
6) cpp/RJ_Networks_Desktop.cpp = aap ka C++ desktop panel

SETUP ORDER:
A) Supabase SQL Editor mein rj_networks_schema.sql run karein.
B) whatsapp_reminder_schema.sql run karein.
C) Authentication > Users mein Admin aur Workers banayein; profiles mein Admin role set karein.
D) web/config.js mein apni Supabase Project URL aur Publishable Key dalein.
E) web/index.html ko HTTPS static hosting par deploy karein. Ye mobile data/Wi-Fi se chalega.
F) WhatsApp ke liye Meta WhatsApp Business Cloud API setup, approved template, access token aur phone number ID chahiye.
G) Edge Function deploy karke required secrets set karein. schedule.sql ko apne project ref ke saath configure karein.

BULK IMPORT FORMAT:
ID|Name|Phone|Package|Fee|Expiry|AreaID|Street|IP|MAC|WorkerID

IMPORTANT:
- Database password aur Supabase Secret/Service Role key browser mein kabhi na rakhein.
- Automatic WhatsApp ke liye customer messaging consent aur Meta-approved template zaroori hai.
- Public internet par access ke liye HTTPS hosting zaroori hai.
